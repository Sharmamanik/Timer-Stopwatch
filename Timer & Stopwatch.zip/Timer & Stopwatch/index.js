let timerInterval;
let stopwatchInterval;
let timerSeconds = 0;
let stopwatchSeconds = 0;

function startTimer() {
    const timerInput = document.getElementById('timer-input');
    const timerDisplay = document.getElementById('timer-display');
    
    if (!timerInput.value || timerInput.value <= 0) {
        alert('Please enter a valid timer value.');
        return;
    }

    timerSeconds = parseInt(timerInput.value, 10);
    timerDisplay.textContent = formatTime(timerSeconds);

    timerInterval = setInterval(function() {
        if (timerSeconds <= 0) {
            clearInterval(timerInterval);
            alert('Timer has finished!');
        } else {
            timerSeconds--;
            timerDisplay.textContent = formatTime(timerSeconds);
        }
    }, 1000);
}

function startStopwatch() {
    const stopwatchDisplay = document.getElementById('stopwatch-display');
    stopwatchInterval = setInterval(function() {
        stopwatchSeconds++;
        stopwatchDisplay.textContent = formatStopwatchTime(stopwatchSeconds);
    }, 1000);
}

function stopStopwatch() {
    clearInterval(stopwatchInterval);
}

function resetStopwatch() {
    const stopwatchDisplay = document.getElementById('stopwatch-display');
    clearInterval(stopwatchInterval);
    stopwatchSeconds = 0;
    stopwatchDisplay.textContent = formatStopwatchTime(stopwatchSeconds);
}

function formatTime(seconds) {
    const minutes = Math.floor(seconds / 60);
    const remainingSeconds = seconds % 60;
    return `${String(minutes).padStart(2, '0')}:${String(remainingSeconds).padStart(2, '0')}`;
}

function formatStopwatchTime(seconds) {
    const hours = Math.floor(seconds / 3600);
    const minutes = Math.floor((seconds % 3600) / 60);
    const remainingSeconds = seconds % 60;
    return `${String(hours).padStart(2, '0')}:${String(minutes).padStart(2, '0')}:${String(remainingSeconds).padStart(2, '0')}`;
}
